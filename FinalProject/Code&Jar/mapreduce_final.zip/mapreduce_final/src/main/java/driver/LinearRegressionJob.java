package driver;

import kvtype.FloatAndFloat;
import kvtype.FloatAndLong;
import mr.LinearRegression;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import util.Utils;


public class LinearRegressionJob {
    public static void main(String[] args) throws Exception {
        if(args.length!= 2){
            System.err.println("Usage: driver.LinearRegressionJob <input_path> <output_path>");
            System.exit(-1);
        }
        String spliter = ",";
        String shuffled_path = args[1] + "/linear_regression_shuffled";
        String sdg_path = args[1] + "/linear_regression_sdg";
        String regression_path = args[1] + "/linear_regression_error";
        String result_path = args[1] + "/linear_regression_result";

        /*
         * 第一步：打乱数据
         * 方法：
         * Mapper端输出随机值作为key，在reducer端直接输出即可
         * randN : 间隔多久生成一次随机数
         */
        Configuration conf = new Configuration();
        int randN = 10;
        conf.setInt(Utils.SHUFFLE_RANDN, randN);

        Job job = Job.getInstance(conf,"Shuffle Data Job");
        job.setJarByClass(LinearRegression.class);

        job.setMapperClass(LinearRegression.ShuffleMapper.class);
        job.setReducerClass(LinearRegression.ShuffleReducer.class);

        job.setMapOutputKeyClass(FloatWritable.class);
        job.setMapOutputValueClass(Text.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(NullWritable.class);

        FileInputFormat.addInputPath(job, Utils.str2Path(args[0]));
        FileOutputFormat.setOutputPath(job,Utils.str2Path(shuffled_path));

        Utils.delete(conf, shuffled_path);
        job.waitForCompletion(true);

        /*
         * 第二步：使用随机梯度下降（SGD）求解每个mapper的最优函数
         * 此方法只针对只有一个全局最优解的情况（如一元一次线性回归）
         * 因为如果每个mapper得到不同的参数Theta，那么在Reducer端如何整合就会有不同的方式
         */
        Configuration conf1 = new Configuration();
        conf1.setLong("mapreduce.input.fileinputformat.split.maxsize",700L);// 获取多个mapper；

        float theta0 = 1.0f;
        float theta1 = 0.0f;
        float theta2 = 0.0f;
        float theta3 = 0.0f;
        float alpha = 0.01f ;

        conf1.setFloat(Utils.LINEAR_THETA0,theta0);
        conf1.setFloat(Utils.LINEAR_THETA1, theta1);
        conf1.setFloat(Utils.LINEAR_THETA2,theta2);
        conf1.setFloat(Utils.LINEAR_THETA3, theta3);
        conf1.setFloat(Utils.LINEAR_ALPHA, alpha);
        conf1.set(Utils.LINEAR_SPLITTER, spliter);

        Job job1 = Job.getInstance(conf1,"Linear Regression Job");

        job1.setJarByClass(LinearRegression.class);
        job1.setMapperClass(LinearRegression.LinearRegressionMapper.class);
//        job.setReducerClass(LinearRegressionReducer.class);// 不需要使用reducer即可
        job1.setNumReduceTasks(0);

//        job.setMapOutputKeyClass(FloatWritable.class);
//        job.setMapOutputValueClass(Text.class);

        job1.setOutputKeyClass(Text.class);
        job1.setOutputValueClass(NullWritable.class);

        FileInputFormat.addInputPath(job1, Utils.str2Path(shuffled_path));
        FileOutputFormat.setOutputPath(job1, Utils.str2Path(sdg_path));
        Utils.delete(conf1, sdg_path);

        job1.waitForCompletion(true);

        /*
         * 第三步：使用第二步中随机梯度下降（SGD求解每个mapper的最优函数 来求解全局误差
         * 有多少个mapper就会有多少个全局误差与之对应
         * Reducer： 根据误差来加权(或平均)得到最终的 最优函数
         *
         */
        Configuration conf2 = new Configuration();

        conf2.set(Utils.SINGLE_LINEAR_PATH, sdg_path);
        conf2.set(Utils.LINEAR_SPLITTER, spliter);

        conf2.set(Utils.SINGLE_REDUCER_METHOD, "weight");
        Job job2 = Job.getInstance(conf2,"Single Linear Regression Error");

        job2.setJarByClass(LinearRegression.class);
        job2.setMapperClass(LinearRegression.SingleLinearRegressionErrorMapper.class);
        job2.setReducerClass(LinearRegression.SingleLinearRegressionErrorReducer.class);//

        job2.setMapOutputKeyClass(FloatAndFloat.class);
        job2.setMapOutputValueClass(FloatAndLong.class);

        job2.setOutputKeyClass(FloatAndFloat.class);
        job2.setOutputValueClass(NullWritable.class);

        FileInputFormat.addInputPath(job2, Utils.str2Path(shuffled_path));
        FileOutputFormat.setOutputPath(job2, Utils.str2Path(regression_path));
        Utils.delete(conf, regression_path);

        job2.waitForCompletion(true);

        /*
         * 第四步：使用第三步中求得的theta值来求解全局误差
         *
         */
        Configuration conf3 = new Configuration();

        conf3.set(Utils.SINGLE_LINEAR_PATH, regression_path);
        conf3.set(Utils.LINEAR_SPLITTER, spliter);

        Job job3 = Job.getInstance(conf3,"Last Linear Regression Error");

        job3.setJarByClass(LinearRegression.class);
        job3.setMapperClass(LinearRegression.SingleLinearRegressionErrorMapper.class);
        job3.setReducerClass(LinearRegression.SingleLinearRegressionErrorReducer2.class);//

        job3.setMapOutputKeyClass(FloatAndFloat.class);
        job3.setMapOutputValueClass(FloatAndLong.class);

        job3.setOutputKeyClass(FloatAndFloat.class);
        job3.setOutputValueClass(FloatWritable.class);

        FileInputFormat.addInputPath(job3, Utils.str2Path(shuffled_path));
        FileOutputFormat.setOutputPath(job3, Utils.str2Path(result_path));
        Utils.delete(conf3, result_path);

        System.exit(job3.waitForCompletion(true) ? 0 : 1);// 等待前一个job完成
    }
}
