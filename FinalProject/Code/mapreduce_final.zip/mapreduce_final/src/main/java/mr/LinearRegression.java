package mr;
import kvtype.FloatAndFloat;
import kvtype.FloatAndLong;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.PathFilter;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import util.Utils;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class LinearRegression {
    //  随机打乱原始数据
    public static class ShuffleMapper extends Mapper<LongWritable,Text, FloatWritable,Text> {
        private Random random = new Random();

        private int randN = 0;
        private int countI = 0;

        private FloatWritable randFloatKey = new FloatWritable(random.nextFloat());

        protected void setup(Context context) throws IOException, InterruptedException {
            randN = context.getConfiguration().getInt(Utils.SHUFFLE_RANDN,0);

        }

        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            if(randN <= 0) { // 如果randN 比0小，那么不再次打乱数据
                context.write(randFloatKey,value);
                return ;
            }
            if(++countI >= randN){// 如果randN等于1，那么每次随机的值都是不一样的
                randFloatKey.set(random.nextFloat());
                countI =0;
            }
            context.write(randFloatKey,value);
        }
    }

    /**
     * Reducer接受的数据已经被打散，直接输出即可
     */
    public static class ShuffleReducer extends Reducer<FloatWritable,Text,Text,NullWritable> {
        protected void reduce(FloatWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            for(Text value: values){
                context.write(value,NullWritable.get());
            }
        }
    }



    /**
     * 每个mapper的map函数更新参数的公式为
     * theta0 = theta0 - alpha *( h(x) - y) * 1
     * theta1 = theta1 - alpha *( h(x) - y) * x1
     * ....
     */
    public static class LinearRegressionMapper extends Mapper<LongWritable, Text, Text, NullWritable> {

        private float theta0 = 1.0f ;
        private float theta1 = 0.0f ;
        private float theta2 = 0.0f;
        private float theta3 = 0.0f;
        private float alpha = 0.01f;
        private String splitter = ",";

        private float lastTheta0 = theta0;
        private float lastTheta1 = theta1;
        private float lastTheta2 = theta2;

        protected void setup(Context context) throws IOException, InterruptedException {
            theta0 = context.getConfiguration().getFloat(Utils.LINEAR_THETA0,1.0f);
            theta1 = context.getConfiguration().getFloat(Utils.LINEAR_THETA1,0.0f);
            theta2 = context.getConfiguration().getFloat(Utils.LINEAR_THETA2,0.0f);
            theta3 = context.getConfiguration().getFloat(Utils.LINEAR_THETA3,0.0f);
            alpha = context.getConfiguration().getFloat(Utils.LINEAR_ALPHA,0.01f);
            splitter = context.getConfiguration().get(Utils.LINEAR_SPLITTER,",");
        }

        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            float[] xy = Utils.str2float(value.toString().split(splitter));
            float y = xy[0];
            float x1 = xy[1];
            float x2 = xy[2];
            float x3 = xy[3];

            // 同步更新 theta0 and theta1
            lastTheta0 = theta0;
            lastTheta1 = theta1;
            lastTheta2 = theta2;

            theta0 -=  alpha * (theta0 + theta1 * x1 + theta2 * x2 + theta3 * x3 - y) * 1;
            theta1 -= alpha * (lastTheta0 + lastTheta1 * x1 + lastTheta2 * x2 + theta3 * x3 - y) * x1;
            theta2 -= alpha * (lastTheta0 + lastTheta1 * x1 + lastTheta2 * x2 + theta3 * x3 - y) * x2;
            theta3 -= alpha * (lastTheta0 + lastTheta1 * x1 + lastTheta2 * x2 + theta3 * x3 - y) * x3;
        }

        private Text theta = new Text();

        protected void cleanup(Context context) throws IOException, InterruptedException {
            theta.set(theta0 + splitter + theta1 + splitter + theta2 + splitter + theta3);
            context.write(theta,NullWritable.get());
        }
    }

    /**
     * 得到每个theta的参数值的全局误差
     */
    public static class SingleLinearRegressionErrorMapper extends Mapper<LongWritable,Text, FloatAndFloat, FloatAndLong> {

        private String thetaPath = null;
        private String splitter = ",";
        private List<float[]> thetas = new ArrayList<>();
        private float[] thetaErrors = null;
        private long [] thetaNumbers = null;

        protected void setup(Context context) throws IOException, InterruptedException {
            thetaPath = context.getConfiguration().get(Utils.SINGLE_LINEAR_PATH,null);
            splitter = context.getConfiguration().get(Utils.LINEAR_SPLITTER,",");
            if(thetaPath == null) {System.err.println("theta path exception");System.exit(-1);}

            FileStatus[] files = FileSystem.get(context.getConfiguration()).listStatus(Utils.str2Path(thetaPath), new PathFilter() {
                @Override
                public boolean accept(Path path) {
                    if(path.toString().contains(Utils.MAPPER_OUTPUT_PREFIX)) return true ;
                    return false;
                }
            });

            for(FileStatus file : files){
                thetas.add(Utils.readFromOneTheatFile(context.getConfiguration(), file.getPath(), splitter));
            }
            thetaErrors = new float[thetas.size()];
            thetaNumbers = new long[thetas.size()];
            System.out.println("thetas array size :" + thetas.size());
        }

        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            float[] xy = Utils.str2float(value.toString().split(splitter));
            float y = xy[0];
            float x1 = xy[1];
            float x2 = xy[2];
            float x3 = xy[3];
            for(int i = 0; i < thetas.size(); i++) {
                // error = (theta0 + theta1 * x1 + theta2 * x2 + theta3 * x3 - y) ^2
                thetaErrors[i] += (thetas.get(i)[0] + thetas.get(i)[1] * x1 + thetas.get(i)[2] * x2
                        + thetas.get(i)[3] * x3 - y) * (thetas.get(i)[0] + thetas.get(i)[1] * x1 + thetas.get(i)[2] * x2
                        + thetas.get(i)[3] * x3 - y);
                thetaNumbers[i]+= 1;
            }
        }

        private FloatAndLong floatAndLong = new FloatAndLong();
        private FloatAndFloat theta = new FloatAndFloat();

        protected void cleanup(Context context) throws IOException, InterruptedException {
            for(int i = 0; i < thetas.size(); i++){
                theta.set(thetas.get(i));
                floatAndLong.set(thetaErrors[i], thetaNumbers[i]);
                context.write(theta,floatAndLong);
            }
        }
    }

    public static class SingleLinearRegressionErrorReducer extends Reducer<FloatAndFloat,FloatAndLong,FloatAndFloat,NullWritable> {
        List<float[]> theta_error = new ArrayList<>();
        String method = "average";
        Logger logger = LoggerFactory.getLogger(getClass());

        protected void setup(Context context) throws IOException, InterruptedException {
            method = context.getConfiguration().get(Utils.SINGLE_REDUCER_METHOD);
        }

        protected void reduce(FloatAndFloat key, Iterable<FloatAndLong> values, Context context) throws IOException, InterruptedException {
            float sumF = 0.0f;
            long sumL = 0L ;
            for(FloatAndLong value:values){
                sumF +=value.getSumFloat();
                sumL += value.getSumLong();
            }
            theta_error.add(new float[]{key.getTheta0(), key.getTheta1(), key.getTheta2(), key.getTheta3(), (float)Math.sqrt((double)sumF / sumL)});
            logger.info("theta:{}, error:{}", new Object[]{key.toString(), Math.sqrt(sumF/sumL)});
        }

        protected void cleanup(Context context) throws IOException, InterruptedException {
            // 如何加权？
            // 方式1：如果误差越小，那么说明权重应该越大；
            // 方式2：直接平均值
            float [] theta_all = new float[4];
            if("average".equals(method)){
//            theta_all = theta_error.get(0);
                for(int i = 0; i < theta_error.size(); i++){
                    theta_all[0] += theta_error.get(i)[0];
                    theta_all[1] += theta_error.get(i)[1];
                    theta_all[2] += theta_error.get(i)[2];
                    theta_all[3] += theta_error.get(i)[3];
                }
                theta_all[0] /= theta_error.size();
                theta_all[1] /= theta_error.size();
                theta_all[2] /= theta_error.size();
                theta_all[3] /= theta_error.size();
            } else {
                float sumErrors = 0.0f;
                for(float[] d:theta_error){
                    sumErrors += 1/d[4];
                }
                for(float[] d: theta_error){
                    theta_all[0] += d[0] * 1/d[4] /sumErrors;
                    theta_all[1] += d[1] * 1/d[4] /sumErrors;
                    theta_all[2] += d[2] * 1/d[4] /sumErrors;
                    theta_all[3] += d[3] * 1/d[4] /sumErrors;
                }
            }
            context.write(new FloatAndFloat(theta_all),NullWritable.get());
        }
    }

    public static class SingleLinearRegressionErrorReducer2 extends Reducer<FloatAndFloat,FloatAndLong,FloatAndFloat,FloatWritable> {
        Logger logger = LoggerFactory.getLogger(getClass());

        protected void reduce(FloatAndFloat key, Iterable<FloatAndLong> values, Context context) throws IOException, InterruptedException {
            float sumF = 0.0f;
            long sumL = 0L ;
            for(FloatAndLong value:values){
                sumF +=value.getSumFloat();
                sumL += value.getSumLong();
            }

            context.write(key, new FloatWritable((float)Math.sqrt((double)sumF / sumL)));
            logger.info("theta:{}, error:{}", new Object[]{key.toString(),Math.sqrt(sumF/sumL)});
        }
    }
}
