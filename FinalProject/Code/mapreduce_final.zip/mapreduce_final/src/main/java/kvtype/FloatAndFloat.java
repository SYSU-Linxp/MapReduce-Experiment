package kvtype;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class FloatAndFloat implements WritableComparable<FloatAndFloat> {

    private float theta0 ;
    private float theta1;
    private float theta2;
    private float theta3;

    public FloatAndFloat(){
        set(0.0f,0.0f,0.0f,0.0f);
    }

    public FloatAndFloat(float[] data){
        set(data);
    }

    public void set(float t1,float t2,float t3,float t4){
        this.theta0 = t1;
        this.theta1 = t2;
        this.theta2 = t3;
        this.theta3 = t4;
    }

    public float getTheta0() {
        return theta0;
    }

    public float getTheta1() {
        return theta1;
    }

    public float getTheta2() {
        return theta2;
    }

    public float getTheta3() {
        return theta3;
    }

    public void set(float[] theta){
        this.theta0 = theta[0];
        this.theta1 = theta[1];
        this.theta2 = theta[2];
        this.theta3 = theta[3];
    }

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeFloat(theta0);
        dataOutput.writeFloat(theta1);
        dataOutput.writeFloat(theta2);
        dataOutput.writeFloat(theta3);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        theta0 = dataInput.readFloat();
        theta1 = dataInput.readFloat();
        theta2 = dataInput.readFloat();
        theta3 = dataInput.readFloat();
    }

    @Override
    public String toString() {
        return this.theta0 + "," + this.theta1 + "," + this.theta2 + "," + this.theta3;
    }

    @Override
    public int compareTo(FloatAndFloat o) {
        if(this.getTheta0() == o.getTheta0()) {
            if(this.getTheta1() < o.getTheta1()) return -1;
            else if (this.getTheta1() == o.getTheta1()) {
                if (this.getTheta2() < o.getTheta2()) return -1;
                else if (this.getTheta2() == o.getTheta2()) {
                    if (this.getTheta3() < o.getTheta3()) return -1;
                    return 1;
                }
            }
            return 1;
        } else if (this.getTheta0()< o.getTheta0()) return -1;
        return 1;
    }
}
