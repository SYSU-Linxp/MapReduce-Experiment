import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class TriangleDriver {
    public static void main(String[] args) throws Exception {
        /*
         * 执行时有2个命令行参数 data/ output_ex4/
         * data即输入文件路径，在这里是有向边关系;
         * output_ex4即job3输出文件路径，即总的三角形个数
         * job1输出文件路径是tmp1，为点和其临接点;
         * job2输出文件路径是tmp2，为每个reducer统计到的三角形个数
         */
        // job1
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
        Job job = new Job(conf, "Triangle_plus1"); //设置job的名字
        job.setJarByClass(TriangleCount.class);
        job.setMapperClass(TriangleCount.FileMapper.class);
        job.setPartitionerClass(TriangleCount.FilePartitioner.class);
        job.setReducerClass(TriangleCount.FileReducer.class);
        job.setMapOutputKeyClass(Text.class);
//        job.setMapOutputValueClass(NullWritable.class);
        job.setMapOutputValueClass(IntWritable.class); // 选做题改为Int
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        job.setNumReduceTasks(500);// 设定reducer数目
        FileInputFormat.setMinInputSplitSize(job, 1);// 设定文件分片，这样才能让多个mapper和reducer实际用起来
        FileInputFormat.setMaxInputSplitSize(job, 10485760);
        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
//        FileOutputFormat.setOutputPath(job, new Path("tmp1/"));
        FileOutputFormat.setOutputPath(job, new Path("tmp1_plus/"));
        job.waitForCompletion(true);
        // job2
        Configuration conf2 = new Configuration();
        Job job2 = new Job(conf2, "Triangle_plus2");
        job2.setJarByClass(TriangleCount.class);
        job2.setMapperClass(TriangleCount.Mapper2.class);
        job2.setReducerClass(TriangleCount.Reducer2.class);
        job2.setMapOutputKeyClass(Text.class);
        job2.setMapOutputValueClass(Text.class);
        job2.setOutputKeyClass(Text.class);
        job2.setOutputValueClass(IntWritable.class);
        job2.setNumReduceTasks(500);// 设定reducer数目
        FileInputFormat.setInputPaths(job2, new Path("tmp1_plus/"));
        FileOutputFormat.setOutputPath(job2, new Path("tmp2_plus/"));
//        FileInputFormat.setInputPaths(job2, new Path("tmp1/"));
//        FileOutputFormat.setOutputPath(job2, new Path("tmp2/"));
        job2.waitForCompletion(true);// 等待前一个job完成
        // job3
        // 不设定reducer数目因为必须只能有1个reducer
        Configuration conf3 = new Configuration();
        Job job3 = new Job(conf3, "Triangle_plus3");
        job3.setJarByClass(TriangleCount.class);
        job3.setMapperClass(TriangleCount.CountMapper.class);
        job3.setReducerClass(TriangleCount.CountReducer.class);
        job3.setMapOutputKeyClass(Text.class);
        job3.setMapOutputValueClass(IntWritable.class);
        job3.setOutputKeyClass(Text.class);
        job3.setOutputValueClass(IntWritable.class);
//        FileInputFormat.setInputPaths(job3, new Path("tmp2/"));
        FileInputFormat.setInputPaths(job3, new Path("tmp2_plus/"));
        FileOutputFormat.setOutputPath(job3, new Path(otherArgs[1]));
        System.exit(job3.waitForCompletion(true) ? 0 : 1);// 等待前一个job完成
    }
}
