import java.io.Serializable;
import java.util.*;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import scala.Tuple2;

public class FreItemSetMining implements Serializable{
    private long minSuport;  //  最小支持度=最小置信度*总样本数
    private String outputPath;  //  输出路径
    private double confidence = 0.9;  //  置信度
    private long numOfItems;  //  总样本数
    private JavaRDD<String> dataset;  //  第一次加载的原始数据集的RDD，统计总样本数
    private List lastList;   //  上一轮得到的频繁项集
    private List<HashSet<String>> K_ciList;  //  K频繁项集
    private String formatString;  //  规范输出格式
    private double formatDouble;  //  规范输出格式
    private String formatDoubleToString;   //  规范输出格式

    //  初始化全局参数，并读入原始数据集
    public FreItemSetMining(JavaRDD<String> transactions,String outputPath) {
        this.outputPath = outputPath;
        this.dataset = transactions;
        this.numOfItems = this.dataset.count();
        this.minSuport = (long) Math.ceil(numOfItems * confidence);
    }

    public void Mining() {
        //  标志现在是多少项集
        int k = 1;
        //  挖掘1频繁项集
        boolean foundItemSet = run();
        //  挖掘频繁项直到不再产生频繁项
        while (foundItemSet) {
            foundItemSet = run(lastList, ++k);
        }
    }

    //  挖掘频繁1-项集
    private boolean run() {
        //  对每一行去除空格并转化为多行,即 [1 2 3] -> [[1],[2],[3]]
        JavaRDD<String> Items = dataset.flatMap((FlatMapFunction<String, String>) line -> {
            StringTokenizer st = new StringTokenizer(line," ");
            List<String> re = new ArrayList<>();
            while(st.hasMoreTokens()){
                re.add(st.nextToken());
            }
            return re.iterator();
        });
        //  map到[item,1],即 [item] -> [item, 1]
        JavaPairRDD ItemsPair = Items.mapToPair((PairFunction<String, String, Integer>) s -> new Tuple2<>(s, 1));
        //  根据item进行reduce(计数), 即 [item, 1],[item, 2] -> [item, 3]
        JavaPairRDD reduceItemsPair = ItemsPair.reduceByKey((Function2<Integer, Integer, Integer>) (i1, i2) -> i1 + i2);
        //  过滤掉小于最小支持度的不合法项集
        JavaPairRDD resultItemsPair = reduceItemsPair.filter((Function<Tuple2<String, Integer>, Boolean>)
                result -> result._2 >= minSuport);

        //  得到输出格式a,b:80,0.8,即[item, n] -> string(item + ":" + num + "," + string(n))
        JavaRDD save = resultItemsPair.flatMap((FlatMapFunction<Tuple2<String, Integer>, String>) line -> {
            formatString = line._1;
            formatDouble = line._2.doubleValue() / numOfItems;
            formatDoubleToString = String.format("%.2f",formatDouble);
            return Arrays.asList((formatString+":" + line._2.toString() + "," + formatDoubleToString)).iterator();
        });
        //  写入HDFS
        save.saveAsTextFile(outputPath+"result-1");
        //  得到1频繁项,作为后面2频繁项的输入
        lastList  = resultItemsPair.map((Function<Tuple2<String, Integer>, HashSet<String>>) t -> {
            HashSet s = new HashSet();
            s.add(t._1);
            return s;
        }).collect();

        return !lastList.isEmpty();
    }

    //  挖掘频繁K项集,注释类似前面1频繁项
    private boolean run(List<HashSet<String>> ciList, int i) {
        //  得到候选的频繁K项集
        K_ciList = getKItemSet(ciList);
        //  对照原数据集,挖掘出实际存在的候选频繁K项集
        JavaRDD<String> KItems = dataset.flatMap((FlatMapFunction<String, String>)
                line -> getItems(K_ciList, line).iterator());
        //  以下部分跟前面1项集类似,就是挖掘频繁K项集
        JavaPairRDD KItemsPair = KItems.mapToPair((PairFunction<String, String, Integer>) s -> new Tuple2<>(s, 1));

        JavaPairRDD KReduceItemsPair=KItemsPair.reduceByKey((Function2<Integer, Integer, Integer>) (i1, i2) -> i1 + i2);

        JavaPairRDD KResultItemsPair = KReduceItemsPair.filter((Function<Tuple2<String, Integer>, Boolean>)
                result -> result._2 >= minSuport);

        JavaRDD save = KResultItemsPair.flatMap((FlatMapFunction<Tuple2<String, Integer>, String>) line -> {
            formatString = line._1.trim().substring(1, line._1.length()-1).trim();  //  去除中括号和多余空格
            formatDouble = line._2.doubleValue() / numOfItems;  //  得到置信度,也就是实验要求的支持度
            formatDoubleToString = String.format("%.2f",formatDouble);
            return Arrays.asList((formatString + ":" + line._2.toString() + "," + formatDoubleToString)).iterator();
        });

        //  写入输出文件
        save.saveAsTextFile(outputPath+"result-"+i);

        // 将字符串形式的集合转化为HashSet形式,作为后面计算下一个项集的输入
        lastList  = KResultItemsPair.map((Function<Tuple2<String, Integer>, HashSet<String>>) t -> {
            HashSet hs = new HashSet();
            String tmp = t._1.trim().substring(1, t._1.length()-1).trim();
            //  [(a, b), (c, d)] -> (a,b) (c,d)
            hs.addAll(Arrays.asList(tmp.split(", ")));
            return hs;
        }).collect();

        return !lastList.isEmpty();
    }

    //  由K-1频繁项集连接生成K频繁项集的候选集合
    private static List<HashSet<String>> getKItemSet(List<HashSet<String>> candidateItem) {
        //  定义一个哈希集合用来放结果
        HashSet<HashSet<String>> K_ciSet = new HashSet();
        int size = candidateItem.size();
        HashSet hs1;  //  K-1频繁项
        HashSet hs2;  //  K频繁项
        for(int i = 0; i < size; i++){
            hs1 = candidateItem.get(i);  //  得到第i个K-1频繁项
            int hsSize = hs1.size();
            for(int j = i; j < size; j++){
                //  得到还没有求交集的第j个K频繁项
                hs2 = (HashSet) candidateItem.get(j).clone();
                //  两个项集求并集
                hs2.removeAll(hs1);
                hs2.addAll(hs1);
                //  如果得到的并集是k频繁项则加入结果
                if((hs2.size() - hsSize) == 1){
                    K_ciSet.add(hs2);
                }
            }
        }
        List<HashSet<String>> K_ciList = new ArrayList(K_ciSet);
        return K_ciList;
    }

    //   从当前的候选集中挖掘实际存在的候选频繁项
    private List<String> getItems(List<HashSet<String>> K_ciList, String line){
        //  解析一行
        StringTokenizer st = new StringTokenizer(line," ");
        List<String> re = new ArrayList<>();
        while(st.hasMoreTokens()){
            re.add(st.nextToken());
        }
        List<String> newLine = new ArrayList();
        for(HashSet<String> hs : K_ciList){
            //  如果原始数据中包含该项集则确实为频繁项集
            if(re.containsAll(hs)){
                String hsToString = hs.toString();
                newLine.add(hsToString);
            }
        }
        return newLine;
    }

    public static void main(String[] args) {
        //  args example of chess dataset:
        //	args[0]:hdfs://localhost:9000/user/stephenlin/data/chess.dat
        //	args[1]:hdfs://localhost:9000/user/stephenlin/spark_output/chess/
        JavaSparkContext context = new JavaSparkContext( "local", "FreItemSetMining",
                System.getenv("SPARK_HOME"), System.getenv("SPARK_EXAMPLES_JAR"));
        JavaRDD distFile = context.textFile(args[0]);
        FreItemSetMining freItemSetMining = new FreItemSetMining(distFile,args[1]);
        freItemSetMining.Mining();
    }
}